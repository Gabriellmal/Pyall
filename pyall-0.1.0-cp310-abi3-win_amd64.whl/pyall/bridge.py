
import os
import tempfile
import sys
from pathlib import Path
from . import pyall_core

def run_cpp(code: str, args=None):
    """Compiles and runs C++ code, returning the output."""
    if args is None: args = []
    
    # Auto-headers
    if "cout" in code and "#include <iostream>" not in code:
        code = "#include <iostream>\n" + code
    
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_path = Path(tmp_dir)
        src = tmp_path / "bridge_code.cpp"
        exe = tmp_path / ("bridge_bin.exe" if os.name == 'nt' else "bridge_bin")
        
        with open(src, "w") as f:
            f.write(code)
            
        # Compile
        code_ret, out = pyall_core.execute_raw("g++", [str(src), "-o", str(exe)])
        if code_ret != 0:
            return f"BUILD ERROR:\n{out}"
            
        # Run
        run_ret, run_out = pyall_core.execute_raw(str(exe), args)
        return run_out

class CPPMagic:
    """Enables the @cpp decorator for mixed-mode coding."""
    def __call__(self, func_or_code):
        if callable(func_or_code):
            # This is a decorator usage
            code = func_or_code.__doc__
            if not code:
                return lambda *args, **kwargs: "Error: No C++ code found in docstring."
            return lambda *args, **kwargs: print(run_cpp(code))
        else:
            # Direct string usage
            return run_cpp(func_or_code)

cpp = CPPMagic()
