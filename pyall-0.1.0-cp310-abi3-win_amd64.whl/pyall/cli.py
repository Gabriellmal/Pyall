
import typer
from .bridge import run_cpp
app = typer.Typer()

@app.command()
def execute(file: str):
    with open(file, 'r') as f:
        print(run_cpp(f.read()))

if __name__ == "__main__":
    app()
