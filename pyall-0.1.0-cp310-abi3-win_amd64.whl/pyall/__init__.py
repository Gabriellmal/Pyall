
from .bridge import cpp, run_cpp
__version__ = '0.1.0'
